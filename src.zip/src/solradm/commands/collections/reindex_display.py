from __future__ import annotations

import asyncio

from rich.console import Group
from rich.live import Live
from rich.table import Table
from rich.text import Text

from solradm.commands.collections.reindex_tracker import ReindexProgressTracker, TargetShardState


class ReindexLiveDisplay:
    def __init__(self, tracker: ReindexProgressTracker, show_count: int = 10) -> None:
        self._tracker = tracker
        self._show_count = show_count
        self._live: Live | None = None
        self._task: asyncio.Task | None = None

    def start(self) -> None:
        self._live = Live(self._render(), refresh_per_second=4)
        self._live.start()
        self._task = asyncio.get_event_loop().create_task(self._loop())

    def stop(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
        if self._live:
            self._live.update(self._render())
            self._live.stop()
            self._live = None

    async def _loop(self) -> None:
        try:
            while not self._tracker.all_done:
                if self._live:
                    self._live.update(self._render())
                await asyncio.sleep(0.25)
        except asyncio.CancelledError:
            pass

    def _render(self) -> Group:
        completed, active, errored = self._tracker.get_summary()
        total = len(self._tracker.targets)

        summary = Text(f"Progress: {completed}/{total} complete, {active} active, {errored} errors")

        slowest = self._tracker.get_slowest(self._show_count)
        fastest = self._tracker.get_fastest(self._show_count)

        slow_table = self._build_table("Slowest Targets", slowest)
        fast_table = self._build_table("Fastest Targets", fastest)

        return Group(summary, slow_table, fast_table)

    def _build_table(self, title: str, targets: list[TargetShardState]) -> Table:
        table = Table(title=title, expand=True)
        table.add_column("Target", style="bold")
        table.add_column("Sources")
        table.add_column("Current")

        for t in targets:
            sources_text = f"{t.completed_sources}/{t.total_sources}"
            if t.current_source and t.is_active:
                total_str = str(t.current_total) if t.current_total is not None else "?"
                current_text = f"{t.current_source}: {t.current_done}/{total_str}"
            elif t.current_source:
                current_text = f"{t.current_source}: done"
            else:
                current_text = "-"
            table.add_row(t.target_name, sources_text, current_text)

        return table
