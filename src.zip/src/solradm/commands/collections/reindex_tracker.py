from __future__ import annotations

import asyncio
from dataclasses import dataclass, field


@dataclass
class TargetShardState:
    target_name: str
    leader_base_url: str
    total_sources: int
    completed_sources: int = 0
    current_source: str | None = None
    current_done: int = 0
    current_total: int | None = None
    is_active: bool = False
    is_complete: bool = False
    error: str | None = None
    import_done_event: asyncio.Event = field(default_factory=asyncio.Event)


class ReindexProgressTracker:
    def __init__(self, shard_map: dict, leaders: dict, dataimport_path: str) -> None:
        self.targets: dict[str, TargetShardState] = {}
        self.dataimport_path = dataimport_path
        for target_name, source_shards in shard_map.items():
            leader = leaders.get(target_name)
            base_url = leader.base_url if leader else ""
            self.targets[target_name] = TargetShardState(
                target_name=target_name,
                leader_base_url=base_url or "",
                total_sources=len(source_shards),
            )

    def start_import(self, target_name: str, source_name: str, source_total: int) -> None:
        state = self.targets[target_name]
        state.import_done_event.clear()
        state.is_active = True
        state.current_source = source_name
        state.current_done = 0
        state.current_total = source_total

    def update_import_progress(self, target_name: str, done: int, total: int | None, status: str | None) -> None:
        state = self.targets[target_name]
        state.current_done = done
        if total is not None:
            state.current_total = total
        if status != "busy":
            state.is_active = False
            state.completed_sources += 1
            state.import_done_event.set()

    def mark_complete(self, target_name: str) -> None:
        state = self.targets[target_name]
        state.is_complete = True
        state.is_active = False

    def mark_error(self, target_name: str, error: str) -> None:
        state = self.targets[target_name]
        state.error = error
        state.is_active = False
        state.is_complete = True
        state.import_done_event.set()

    def get_active_targets(self) -> list[TargetShardState]:
        return [s for s in self.targets.values() if s.is_active]

    def get_slowest(self, n: int) -> list[TargetShardState]:
        incomplete = [s for s in self.targets.values() if not s.is_complete and s.error is None]
        incomplete.sort(key=lambda s: s.completed_sources / max(s.total_sources, 1))
        return incomplete[:n]

    def get_fastest(self, n: int) -> list[TargetShardState]:
        incomplete = [s for s in self.targets.values() if not s.is_complete and s.error is None]
        incomplete.sort(key=lambda s: s.completed_sources / max(s.total_sources, 1), reverse=True)
        return incomplete[:n]

    def get_summary(self) -> tuple[int, int, int]:
        completed = sum(1 for s in self.targets.values() if s.is_complete and s.error is None)
        active = sum(1 for s in self.targets.values() if s.is_active)
        errored = sum(1 for s in self.targets.values() if s.error is not None)
        return completed, active, errored

    @property
    def all_done(self) -> bool:
        return all(s.is_complete for s in self.targets.values())
