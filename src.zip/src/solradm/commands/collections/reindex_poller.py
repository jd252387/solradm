from __future__ import annotations

import asyncio
import logging

from solradm.api.utils import send_request
from solradm.commands.collections.reindex_tracker import ReindexProgressTracker

logger = logging.getLogger(__name__)


def _parse_status(json_resp: dict) -> tuple[int, int | None, str | None]:
    import re

    msgs = json_resp.get("statusMessages", {})
    percent = None
    processed = None
    total = None
    for k, v in msgs.items():
        match = re.search(r"(\d+)", str(v))
        if not match:
            continue
        num = int(match.group(1))
        lk = k.lower()
        if "percent" in lk:
            percent = num
        elif "processed" in lk:
            processed = num
        elif "total" in lk:
            total = num
    if percent is not None:
        return percent, 100, json_resp.get("status")
    return processed or 0, total, json_resp.get("status")


async def run_staggered_polling(
    tracker: ReindexProgressTracker,
    dataimport_path: str,
    poll_interval: float = 1.0,
) -> None:
    """Poll active targets with even time distribution across the interval."""
    while not tracker.all_done:
        active = tracker.get_active_targets()
        if not active:
            await asyncio.sleep(0.1)
            continue

        stagger_delay = poll_interval / len(active)
        for target in active:
            try:
                stat = await send_request(
                    target.leader_base_url,
                    dataimport_path,
                    params={"command": "status", "wt": "json"},
                )
                done, total, status = _parse_status(stat)
                tracker.update_import_progress(target.target_name, done, total, status)
            except Exception as exc:
                logger.warning("Poll failed for %s: %s", target.target_name, exc)
            await asyncio.sleep(stagger_delay)
